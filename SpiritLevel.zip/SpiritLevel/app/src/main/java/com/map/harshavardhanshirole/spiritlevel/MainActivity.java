package com.map.harshavardhanshirole.spiritlevel;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor sensor;
    private long lastTime= 0;
    private int counter=0;
    private float total=0.0f;
    private float average;
    private String message;
    TextView tv_message;

    TextView tv_avg_value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
       sensor= sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_NORMAL);
        tv_avg_value=(TextView) findViewById(R.id.avg_value);
        tv_message=(TextView) findViewById(R.id.message);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        Sensor sensor = sensorEvent.sensor;

        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            //     float z = sensorEvent.values[1];
            Log.i("x", Float.toString(x));
            long currentTime = System.currentTimeMillis();

            if (currentTime - lastTime > 1000) {
                lastTime = currentTime;
                Log.i("x", Float.toString(x));
                //  Log.i("y", Float.toString(y));
                counter = counter + 1;
                total = total + x;

                //  Log.i("y", Float.toString(y));
                if (counter == 20) {
                    average = total / counter;
                    tv_avg_value.setText(String.format("%.2f", average));

                    if (average <= -0.01) {
                        message = "Top edge is too in the right.Relocate to center";
                    } else if (average >= 0.1) {
                        message = "Top right corner is in the left.Relocate to center";

                    }
                    tv_message.setText(message);
                }
            }
        }
    }

public void reset(View v){

    counter=0;
    average=0;
    total=0;

    tv_avg_value.setText("Displayed value is here");
    tv_message.setText("Please wait 10 seconds");

}

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {


    }
}
